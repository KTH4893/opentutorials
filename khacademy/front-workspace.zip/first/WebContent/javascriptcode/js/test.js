function test(){
    alert("외부파일 읽어옴");
}