package org.kh.member.contoroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kh.member.model.dao.MemberDao;
import org.kh.member.model.vo.Member;

/**
 * Servlet implementation class SelectAll
 */
@WebServlet("/selectAll")
public class SelectAll extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectAll() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//인코딩
		request.setCharacterEncoding("utf-8");
		//변수저장
		//비즈니스로직
		MemberDao dao = new MemberDao();
		ArrayList<Member> list = dao.selectAll();
		
		//결과내보내기
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>전체 조회 페이지</title></head>");
		out.println("<body>");
		out.println("<style>");
		out.println("table,tr,th,td{");
		out.println("border:1px solid black;");
		out.println("}");
		out.println("</style>");
		out.println("<table>");
			out.println("<tr>");
				out.println("<th>아이디</th>");
				out.println("<th>패스워드</th>");
				out.println("<th>이름</th>");
				out.println("<th>이메일</th>");
				out.println("<th>나이</th>");
				out.println("<th>주소</th>");
				out.println("<th>성별</th>");
				out.println("<th>가입일</th>");
			out.println("</tr>");
			
			for(int i=0; i<list.size();i++) {
			out.println("<tr>");
				out.println("<td>"+list.get(i).getMemberId()+"</td>");							
				out.println("<td>"+list.get(i).getMemberPw()+"</td>");			
				out.println("<td>"+list.get(i).getMemberName()+"</td>");				
				out.println("<td>"+list.get(i).getEmail()+"</td>");				
				out.println("<td>"+list.get(i).getAge()+"</td>");				
				out.println("<td>"+list.get(i).getAddr()+"</td>");				
				out.println("<td>"+list.get(i).getGender()+"</td>");	
				out.println("<td>"+list.get(i).getEnrollDate()+"</td>");
			out.println("</tr>");
			}
			out.println("<a href='/views/smember/login.html'>로그인 화면으로 가기</a>");
		out.println("</table>");
		out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
