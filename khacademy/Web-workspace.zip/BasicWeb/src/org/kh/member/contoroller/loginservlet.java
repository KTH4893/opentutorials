package org.kh.member.contoroller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kh.member.model.dao.MemberDao;
import org.kh.member.model.vo.Member;

/**
 * Servlet implementation class loginservlet
 */
@WebServlet(name = "login", urlPatterns = { "/login" })
public class loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginservlet() {
        super();
        // TODO Auto-generated constructor stub
    }
 
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		//인코딩
		request.setCharacterEncoding("utf-8");
		//변수저장
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		//비즈니스로직
		MemberDao dao = new MemberDao();
		Member m = dao.login(id, pw);
		//결과내보내기
		response.setContentType("text/html; charset=UTF-8");
		//여기서 utf-8은 내보내는설정
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>로그인 결과 페이지</title></head>");
		out.println("<body>");
		
		if(m != null) {
			//로그인성공
			out.println("<h2>로그인성공</h2><hr>");
			out.println("<p>" +m.getMemberName()+"님 환영합니다.</p>");
			out.println("<a href='/selectAll'>전체회원조회</a>");
		} else {
			//로그인실패
			out.println("<h2>로그인 실패</h2><hr>");
			out.println("<a href='/views/smember/login.html'>로그인 화면으로 가기</a>");
		}
		out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
