package kh.java.test;

public class CloneTest implements Cloneable{
	private int data;

	public CloneTest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CloneTest(int data) {
		super();
		this.data = data;
	}

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}
	//�������� �̿��ϸ� CloneTest, CloneTest2
	//Object�� �ļ� -> ObjectŸ������ ����
	
	
	
}
