package product.run;

import product.model.vo.Product;

public class TestProduct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product product = new Product();
		product.printProduct();
	}

}
