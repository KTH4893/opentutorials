package kh.java.controller;

public class RentMgr {

}
