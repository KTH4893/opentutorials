package com.kh.var;

public class TestVar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int kh;		// int kh = 1
		kh = 1;
		System.out.println(kh + 1);
		// return kh;			2 3�� ����̾ȵǴ� ����
		kh = 2;
		System.out.println(kh +1);
		
		System.out.println(true + "");
	}

}
