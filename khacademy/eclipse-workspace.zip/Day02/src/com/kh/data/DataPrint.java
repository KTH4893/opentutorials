package com.kh.data;

//import java.math.BigInteger;

public class DataPrint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println(1+1);							��ü�ּ� Ctrl+slash or /* */
//		System.out.println(1.1+1.1);
//		System.out.println('1'+'1');
//		System.out.println("1"+"1");
//		System.out.println("Hello"+'q');
//		System.out.println("Hello"+3.14);
//		System.out.println(10+20+"Hello");
//		System.out.println(10+"Hello"+20);
//		System.out.println("Hello"+10);
//		System.out.println(10+"Hello");
//		System.out.println(10+(20+"Hello"));
//		System.out.println(20+'q');
		
//		boolean bool = true;
//		boolean bool2 = false;
//		
//		char ch = 'A';
//		
//		String str = "Hello Java";
//		
//		int num = 0;
//		byte bnum;
//		short snum;
//		long lnum;
//		
//		double dnum = 1.1;
//		float fnum = 1.23f;			//(float) 1.23;    <--- �̷��� ǥ������

//		int num = 100;
//		
//		BigInteger lnum = new BigInteger("999900000000");
//		float fnum = (float) 486.520;
//		double dnum = 567.8901230d;
//		
//		long knum = 999900000000l;
//		
//		char ch = 'a';
//		String str = "Hello world";
//		boolean bool = true;
//		
//		System.out.println("���� : " +num);
//		System.out.println("�Ǽ�(float) : " +fnum);
//		System.out.printf("�Ǽ�(float) : %.3f\n ", fnum);
//		System.out.println("�Ǽ� : " +dnum);
//		System.out.println("���� : " +ch);
//		System.out.println("���ڿ� : " +str);
//		System.out.println("���� : " +bool);
//		System.out.println("����(Biginteger) : " +lnum);
//		System.out.println("����(long) : " +knum);
		
//		boolean bool = true;
//		boolean bool = (3 > 2);
//		boolean bool = (1 == 2);
//		System.out.println(bool);
		
		char k1 = 'a';
		char k2 = 97;
		char k3 = '\u0061';				//<----- 16����ǥ�� \u0000
		
		System.out.println(k1);
		System.out.println(k2);
		System.out.println(k3);
		
	}

}
