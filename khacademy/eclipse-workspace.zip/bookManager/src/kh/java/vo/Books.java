package kh.java.vo;

public class Books {
	private String bookNum;		//å��ȣ
	private int bookOf;				//�з�
	private String bookName; 	//����
	private String bookMaker;	//����
	public Books() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Books(String bookNum, int bookOf, String bookName, String bookMaker) {
		super();
		this.bookNum = bookNum;
		this.bookOf = bookOf;
		this.bookName = bookName;
		this.bookMaker = bookMaker;
	}
	public String getBookNum() {
		return bookNum;
	}
	public void setBookNum(String bookNum) {
		this.bookNum = bookNum;
	}
	public int getBookOf() {
		return bookOf;
	}
	public void setBookOf(int bookOf) {
		this.bookOf = bookOf;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBookMaker() {
		return bookMaker;
	}
	public void setBookMaker(String bookMaker) {
		this.bookMaker = bookMaker;
	}
	
	
	
	
}
