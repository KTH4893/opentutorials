package kh.java.run;

import kh.java.view.BookView;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookView bk = new BookView();
		bk.main();

	}
	
	
	
	
}
