package com.kh.run;

import com.kh.controller.StudentMgr;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentMgr sm = new StudentMgr();
		sm.main();
	}

}
