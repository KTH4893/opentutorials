package cording.vo;

public class User {
	private String id;
	private String pw;
	private double score;
	private double speed;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String id, String pw, double score, double speed) {
		super();
		this.id = id;
		this.pw = pw;
		this.score = score;
		this.speed = speed;
	}
	public User(String id, String pw) {
		super();
		this.id = id;
		this.pw = pw;
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	
}
