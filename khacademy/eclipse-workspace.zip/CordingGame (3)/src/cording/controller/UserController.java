package cording.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

import cording.view.View;
import cording.vo.User;

public class UserController {
	Scanner sc = new Scanner(System.in);
	public ArrayList<User> users = new ArrayList<User>();
	Calendar startTime = null;
	Calendar endTime = null;
	double[] arr = new double[2];

	public int userInstall(User u) {
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i).getId().equals(u.getId())) {
				users.add(u);
				return -1;
			}
		}
		users.add(u);
		return 0;

	}

	public ArrayList<User> userlist() {

		return users;
	}

	public boolean userSearch(User user) {

		for (int i = 0; i < users.size(); i++) {

			if (users.get(i).getId().equals(user.getId())&&users.get(i).getPw().equals(user.getPw())) {
				return true;
			}
		}

		return false;
	}

	public boolean userSearch(String id) {

		for (int i = 0; i < users.size(); i++) {

			if (users.get(i).getId().equals(id)) {
				return true;
			}
		}

		return false;
	}

	public int game2Sel() {

		String[] gamelevel = new String[3];
		for (int i = 0; i < gamelevel.length; i++) {
			gamelevel[i] = "��";
		}
		for (int i = 0; i < gamelevel.length; i++) {
			System.out.print(gamelevel[i] + "\t");
		}
		System.out.print("\n�ܰ� ����[1.�ϼ�/2.�߼�/1.����] :  ");
		int sel = sc.nextInt();
		gamelevel[sel - 1] = "��";
		for (int i = 0; i < gamelevel.length; i++) {
			System.out.print(gamelevel[i] + "\t");
		}
		String level = game2LevelName(sel);
		System.out.println("\n" + level + "�� ������ �����Ͻðڽ��ϱ�(Y/N) : ");

		return sel;

	}
	

	public String game2LevelName(int sel) {
		String level = "";
		switch (sel) {
		case 1:
			level = "�ϼ�";
			break;
		case 2:
			level = "�߼�";
			break;
		case 3:
			level = "����";
			break;

		}
		return level;
	}
	
	public double[] game2_1() {// �ϼ�
		String check = "";
		double time1 = 0;
		double time2 = 0;
		arr[0] = 0;
		arr[1] = 0;

		System.out.println("������ �����ϰ� ������[����]�� �Է�  ");
		check = sc.next();
		if (check.equals("����")) {
			time1 = speedCheck(check);
			char c = game211();
			arr[1]+=10;
			if (c == 'Y') {
				char d = game212();
				arr[1]+=10;
				if (d == 'Y') {
					game213();
					arr[1]+=10;
					System.out.println("������ ������ ������ [��]�� �Է� ");
					sc.nextLine();
					check = sc.next();
					time2 = speedCheck(check);
				}
			}
		
		}
		
		arr[0] = time2 - time1;
		return arr;
	
	}

	public double game2_2() {// �߼�
		String check = "";
		System.out.println("������ �����ϰ� ������[����]�� �Է�, ������ ������ ������ [��]�� �Է� ");
		check = sc.next();
		double speed = speedCheck(check);
		// ���⼭ ���Ӻҷ���
		if (check.equals("����")) {
			game212();
		}
		return speed;

	}

	public double game2_3() {

		String check = "";
		System.out.println("������ �����ϰ� ������[����]�� �Է�, ������ ������ ������ [��]�� �Է� ");
		double speed = speedCheck(check);
		// ���⼭ ���Ӻҷ���
		return speed;
	}

	public double speedCheck(String check) {
		// Ÿ��*60/�帥�� = Ÿ�ڼӵ�
		// �����ʿ��� �� �ʻ���

		double timeResult = 0;

		if (check.equals("����")) {
			startTime = Calendar.getInstance();
			int yearS = startTime.get(Calendar.YEAR);
			int monthS = startTime.get(Calendar.MONTH) + 1;
			int dateS = startTime.get(Calendar.DATE);
			return (startTime.getTimeInMillis() / 1000);
		} else if (check.equals("��")) {
			// ���� �����ϱ�
			endTime = Calendar.getInstance();
			int yearE = endTime.get(Calendar.YEAR);
			int monthE = endTime.get(Calendar.MONTH) + 1;
			int dateE = endTime.get(Calendar.DATE);
			return (endTime.getTimeInMillis() / 1000);
			// timeResult = (endTime.getTimeInMillis() / 1000) -
			// (startTime.getTimeInMillis() / 1000);
		}
		return timeResult;
	}

	public char game211() { // �ϼ�

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader("�ϼ�.txt");
			br = new BufferedReader(fr);

			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println(line);
			}
			while (true) {
				System.out.print("���� : ");
				String o = sc.next();
				if (o.equals("args")) {
					System.out.println("�����Դϴ�.");
					System.out.println("���� ���� �����Ͻðڽ��ϱ�? (Y/N)");

					char c = sc.next().charAt(0);

					return c;
				}
				System.out.println("Ʋ�Ƚ��ϴ� ������ �ϼ���");

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}

	public char game212() {// �ϼ�1

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader("�ϼ�1.txt");
			br = new BufferedReader(fr);

			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println(line);
			}
			while (true) {
				System.out.print("���� : ");
				int o = sc.nextInt();
				if (o == 4) {
					System.out.println("�����Դϴ�.");
					System.out.println("���� ���� �����Ͻðڽ��ϱ�? (Y/N)");
					char c = sc.next().charAt(0);

					return c;
				}
				System.out.println("Ʋ�Ƚ��ϴ� ������ �ϼ���");
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}

	public void game213() {// �ϼ�2

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader("�ϼ�2.txt");
			br = new BufferedReader(fr);

			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println(line);
			}
			while (true) {
				System.out.print("���� : ");
				int o = sc.nextInt();
				if (o == 8) {
					System.out.println("�����Դϴ�.");
					System.out.println("�ϼ� Ż��!");
					break;

				} else {
					System.out.println("Ʋ�Ƚ��ϴ� ������ �ϼ���");
				}

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public char game221(String sel) {// �߼�

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader("�߼�.txt");
			br = new BufferedReader(fr);

			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println(line);
			}
			while (true) {
				System.out.print("���� : ");
				String o = sc.next();
				if (o.equals("������")) {
					System.out.println("�����Դϴ�.");
					System.out.println("���� ���� �����Ͻðڽ��ϱ�? (Y/N)");
					char c = sc.next().charAt(0);

					return c;
				}
				System.out.println("Ʋ�Ƚ��ϴ� ������ �ϼ���");
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;

	}

	public char game222(String sel) {// �߼�1

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader("�߼�1.txt");
			br = new BufferedReader(fr);

			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println(line);
			}
			while (true) {
				System.out.print("���� : ");
				String o = sc.next();
				if (o.equals("�����ε�")) {
					System.out.println("�����Դϴ�.");
					System.out.println("���� ���� �����Ͻðڽ��ϱ�? (Y/N)");
					char c = sc.next().charAt(0);

					return c;
				} else {
					System.out.println("Ʋ�Ƚ��ϴ� ������ �ϼ���");
				}

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}

	public void game223(String sel) {// �߼�2

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader("�߼�2.txt");
			br = new BufferedReader(fr);

			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println(line);
			}
			while (true) {
				System.out.print("���� : ");
				String o = sc.next();
				if (o.equals("���׸�")) {
					System.out.println("�����Դϴ�.");
					System.out.println("�߼� Ż��!");
					break;
				} else {
					System.out.println("Ʋ�Ƚ��ϴ� ������ �ϼ���");
				}

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public char game231(String sel) {// ����

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(sel + ".txt");
			br = new BufferedReader(fr);

			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println(line);
			}
			while (true) {
				System.out.print("���� : ");
				int o = sc.nextInt();
				if (o == 8) {
					System.out.println("�����Դϴ�.");
					System.out.println("���� ���� �����Ͻðڽ��ϱ�? (Y/N)");
					char c = sc.next().charAt(0);

					return c;
				} else {
					System.out.println("Ʋ�Ƚ��ϴ� ������ �ϼ���");
				}

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}

	public char game232(String sel) {// ����1

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(sel + "1.txt");
			br = new BufferedReader(fr);

			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println(line);
			}
			while (true) {
				System.out.print("���� : ");
				int o = sc.nextInt();
				if (o == 8) {
					System.out.println("�����Դϴ�.");
					System.out.println("���� ���� �����Ͻðڽ��ϱ�? (Y/N)");
					char c = sc.next().charAt(0);

					return c;
				} else {
					System.out.println("Ʋ�Ƚ��ϴ� ������ �ϼ���");
				}

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}

	public void game233(String sel) {// ����2
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(sel + "2.txt");
			br = new BufferedReader(fr);

			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println(line);
			}
			while (true) {
				System.out.print("���� : ");
				int o = sc.nextInt();
				if (o == 8) {
					System.out.println("�����Դϴ�.");
					System.out.println("���� Ż��!");
					break;
				} else {
					System.out.println("Ʋ�Ƚ��ϴ� ������ �ϼ���");
				}

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public ArrayList<User> userRank() {
		// TODO Auto-generated method stub
		// ArrayList<User> userRank = new ArrayList<User>();
		// double[] result = new double[users.size()];
		// for(int i=0;i<users.size();i++) {
		// result[i-1] = users.get(i).getScore()+users.get(i).getSpeed();
		// }
		Collections.reverse(users);
		return users;
	}

	public void addScore(User user, double[] arrUser) {
		for(int i=0;i<users.size();i++) {
			if(users.get(i).getId().equals(user.getId())) {
				users.get(i).setScore(arrUser[0]);
				users.get(i).setSpeed(arrUser[1]);
			}
		}
	}

	public void addSpeed(User user, double speed) {
		for(int i = 0; i<users.size(); i++) {
			if(users.get(i).getId().equals(user.getId())) {
				users.get(i).setSpeed(speed);
			}
			
		}
		
		
		
	}
	
	
	
	
	
	
	
	
}
