package cording.run;

import cording.view.View;

public class Run {
public static void main(String[] args) {
	View v = new View();
	v.game();
}
}
