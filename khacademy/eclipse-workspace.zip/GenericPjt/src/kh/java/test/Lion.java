package kh.java.test;

public class Lion {
	public int hp;
	public Lion(int hp) {
		super();
		this.hp = hp;
	}
}
