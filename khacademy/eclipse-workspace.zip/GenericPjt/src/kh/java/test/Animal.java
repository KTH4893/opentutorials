package kh.java.test;

public class Animal<T> {
	public T data;
	public Animal(T data) {
		this.data = data;
	}
}
