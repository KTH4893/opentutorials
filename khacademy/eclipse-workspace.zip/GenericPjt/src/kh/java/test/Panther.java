package kh.java.test;

public class Panther {
	public int hp;
	
	public Panther(int hp) {
		super();
		this.hp = hp;
	}
	
	
	
}
