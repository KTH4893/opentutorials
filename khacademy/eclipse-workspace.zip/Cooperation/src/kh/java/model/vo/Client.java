package kh.java.model.vo;

public class Client extends Common{
	private String name;
	private String idNumber;
	private int license;
	private boolean insure;
	private int day;
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public Client(){
		
	}
	public Client(String name, String idNumber, int license, boolean insure){
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdNumber() {
		return idNumber;
	}
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}
	public int getLicense() {
		return license;
	}
	public void setLicense(int license) {
		this.license = license;
	}
	public boolean isInsure() {
		return insure;
	}
	public void setInsure(boolean insure) {
		this.insure = insure;
	}
	
}
