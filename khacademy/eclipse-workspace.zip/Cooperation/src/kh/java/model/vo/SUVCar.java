package kh.java.model.vo;

public class SUVCar extends Common {
	public SUVCar() {

	}

	public SUVCar(String size, int day, String name) {
		super(size, day, name);
	}

	public SUVCar(String size, int day, String name, int price, int insure) {
		super(size, day, name, price, insure);
	}

	public SUVCar(String size, String name, int price, int insure) {
		super(size, name, price, insure);
	}
}
