package kh.java.model.vo;

public class LargeCar extends Common {
	public LargeCar() {

	}

	public LargeCar(String size, int day, String name) {
		super(size, day, name);
	}

	public LargeCar(String size, int day, String name, int price, int insure) {
		super(size, day, name, price, insure);
	}
	public LargeCar(String size, String name, int price, int insure) {
		super(size, name, price, insure);
	}
}
