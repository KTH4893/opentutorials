package kh.java.model.vo;

public class Common {
	// �⺻������
	String size;
	String name;
	int price;
	int insure;
	int day;

	public Common() {

	}
	//size, day, name, price, insure
	// �߰������� (�ֹι�ȣ, �̸�, ����, �ϼ�)
	public Common(String size,int day, String name) {
		this.size = size;
		this.day = day;
		this.name = name;
	}
	public Common(String size, int day,String name, int price, int insure) {
		this.size = size;
		this.name = name;
		this.day = day;
		this.price = price;
		this.insure = insure;
	}
	public Common(String size, String name, int price, int insure) {
		this.size = size;
		this.name = name;
		this.price = price;
		this.insure = insure;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getInsure() {
		return insure;
	}

	public void setInsure(int insure) {
		this.insure = insure;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
