package kh.java.model.vo;

public class MidiumCar extends Common {
	public MidiumCar() {

	}

	public MidiumCar(String size, int day, String name) {
		super(size, day, name);
	}

	public MidiumCar(String size, int day, String name, int price, int insure) {
		super(size, day, name, price, insure);
	}

	public MidiumCar(String size, String name, int price, int insure) {
		super(size, name, price, insure);
	}
}
