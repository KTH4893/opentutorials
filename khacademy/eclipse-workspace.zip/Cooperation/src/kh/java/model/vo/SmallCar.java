package kh.java.model.vo;

public class SmallCar extends Common {
	public SmallCar() {

	}

	public SmallCar(String size, int day, String name) {
		super(size, day, name);
	}

	public SmallCar(String size, int day, String name, int price, int insure) {
		super(size, day, name, price, insure);
	}

	public SmallCar(String size,  String name, int price, int insure) {
		super(size,  name, price, insure);
	}
}
