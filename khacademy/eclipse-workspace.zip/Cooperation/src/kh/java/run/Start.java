package kh.java.run;

import kh.java.controller.RentMgr;

public class Start {

	public static void main(String[] args) {
		RentMgr rm = new RentMgr();
		rm.open();
	}

}
