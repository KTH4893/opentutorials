package com.kh.calc;

import java.util.Scanner;

public class Calc01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("a b c ������ ������� �Է����ּ��� : ");
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		
//		a = a++; �� a++; �� �ٸ���
		
		a++;
		System.out.println(a);
		b = (--a)+b;
		System.out.println(b);
		c = (a++)+(--b);
		System.out.println(c);
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("c = " + c);
		
		boolean flag = true;
		System.out.println(!!!!flag);
		
		int x = 100, y = 33, z = 0;
		
		x--;
		System.out.println("x = " + x);
		z = x-- + --y;
		System.out.println("x = " + x);
		x = 99 + x++ + x;
		System.out.println("x = " + x);
		y = y-- + y + ++y;
		System.out.println("x = " + x);
		System.out.println("y = " + y);
		System.out.println("z = " + z);
		
		
	}

}
