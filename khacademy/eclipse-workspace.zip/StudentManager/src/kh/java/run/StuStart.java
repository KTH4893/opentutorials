package kh.java.run;

import kh.java.view.View;

public class StuStart {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		View v = new View();
		v.main();
	}
}
