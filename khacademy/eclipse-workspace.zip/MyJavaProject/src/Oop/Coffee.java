package Oop;

public class Coffee {
	
	/*�µ� : Temperature	int
	 * ���� : kindof			String
	 * Ŀ�� : Coffee			String
	 * ũ�� : Size			String
	 * ���� : Num			int
	 */
	private String type,been,size,temper;
	private int  num;
	
	
	
	
	public String getBeen() {
		return been;
	}
	public void setBeen(String been) {
		this.been = been;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getTemper() {
		return temper;
	}
	public void setTemper(String temper) {
		this.temper = temper;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	
	
	
}
