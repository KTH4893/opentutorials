
public class HelloJava {
	public static void main(String [] args)
	{
		String name = "HelloJava";
		System.out.println(name);
		
	}
}
