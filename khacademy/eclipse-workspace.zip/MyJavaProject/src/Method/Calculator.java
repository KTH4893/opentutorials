package Method;

import java.util.Scanner;

public class Calculator {
	public void main() {
		Scanner sc = new Scanner(System.in);
		boolean bool = true;
		while (bool) {
		System.out.print("ù��° �����Է� : ");
		int num1 = sc.nextInt();
		System.out.print("�ι�° �����Է� : ");
		int num2 = sc.nextInt();
		System.out.print("������ �Է� (+,-,*,/) : ");
		char cal = sc.next().charAt(0);
			switch (cal) {
			case '+':
				add(num1, num2);
				break;
			case '-':
				sub(num1, num2);
				break;
			case '*':
				mul(num1, num2);
				break;
			case '/':
				div(num1, num2);
				break;
			}
			System.out.println("�ѹ� �� �Ͻðڽ��ϱ�? (y/n)");
			char choi = sc.next().charAt(0);
			if (choi == 'y') {
				bool = true;
			} else {
				bool = false;
			}
		}

	}

	public void add(int num1, int num2) {
		int result = num1 + num2;
		System.out.println("��� ��� : " + result);
	}

	public void sub(int num1, int num2) {
		int result = num1 - num2;
		System.out.println("��� ��� : " + result);
	}

	public void mul(int num1, int num2) {
		int result = num1 * num2;
		System.out.println("��� ��� : " + result);
	}

	public void div(int num1, int num2) {
		double result = num1 / (double) num2;
		System.out.printf("��� ��� : %.3f" , result);
	}

}
