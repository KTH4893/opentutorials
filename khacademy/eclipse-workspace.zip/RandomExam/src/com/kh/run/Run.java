package com.kh.run;

import com.kh.game.UpAndDown;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UpAndDown uad = new UpAndDown();
		uad.main1();
	}

}
