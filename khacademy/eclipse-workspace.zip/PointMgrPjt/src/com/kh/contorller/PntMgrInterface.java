package com.kh.contorller;

public interface PntMgrInterface {
	public void insertData() ;
	public void start();
	public int searchData();
	public void printData();
	public void printDataOne();
	public void modifyData();
	public void deleteData();
	
}
