package com.kh.vo;

public class Vvip extends Grade{

	
	public Vvip() {
		
	}
	
	public Vvip(String grade, String name, int point) {
		super(grade, name, point);
	}
	
	@Override
	public double getBonus() {
		return getPoint() * 0.7;
	}
	
}
