package com.kh.vo;

public class Animal {
	public void eating() {
		System.out.println("�߹̾߹�");
	}
	
	
	
	
	
	
	
	
	
	
	
}
