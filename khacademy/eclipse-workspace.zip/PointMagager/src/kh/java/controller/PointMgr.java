package kh.java.controller;

import java.util.Scanner;

import kh.java.vo.Grade;

public class PointMgr {
	private Grade [] g = new Grade[10];
	private int index = 0;
	public PointMgr() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public void insert(String grade, String name, int point) {
		g[index++] = new Grade(grade, name, point);
	}
	public int count() {
		return index;
	}
	public Grade[] printData() {
		return g;
	}
	public int search(String name) {
		for(int i = 0; i < g.length; i++) {
			if (g[i].getName().equals(name)){
				return i;
			}
		}
		return -1;
	}
	public Grade printOne(int result) {
		return g[result];
	}
	public void insertData(String grade, String name, int point, int result) {
		g[result].setGrade(grade);
		g[result].setName(name);
		g[result].setPoint(point);
	}
	public void deleteData(int result) {
		for(int i = result; i < index-1; i++) {
			g[result] = g[result+1];
		}
		g[index--] = null;
	}
	
	
	
	
}
