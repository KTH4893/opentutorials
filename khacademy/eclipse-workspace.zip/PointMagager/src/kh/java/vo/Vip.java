package kh.java.vo;

public class Vip extends Grade {

	public Vip() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Vip(String grade, String name, int point) {
		super(grade, name, point);
	}
	public double getBonus(){
		return getPoint()*0.1;
	}
}
