package kh.java.vo;

public class Grade {
	private String grade;
	private String name;
	private int point;
	
	//�⺻������
	public Grade() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//�߰�������
	public Grade(String grade, String name, int point) {
		super();
		this.grade = grade;
		this.name = name;
		this.point = point;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPoint() {
		return point;
	}
	public void setPoint(int point) {
		this.point = point;
	}
	
	public double getBonus(String grade) {
		double bonus = 0;
		switch(grade) {
		case "Silver" :bonus = 0.03;
			break;
		case "Gold" : bonus =0.05;
			break;
		case "Vip" : bonus = 0.1;
			break;
		case "Vvip" : bonus = 0.2;
			break;
		}
		return bonus;
	}
	
	
}
