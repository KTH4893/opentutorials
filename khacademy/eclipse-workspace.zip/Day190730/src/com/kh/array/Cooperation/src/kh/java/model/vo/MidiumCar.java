package com.kh.array.Cooperation.src.kh.java.model.vo;

public class MidiumCar {

}
