package com.kh.array.Cooperation.src.kh.java.controller;

import java.util.Scanner;

public class RentMgr {
	Scanner sc = new Scanner(System.in);
	
	public void rentMgr() {
		
	}
	
	public void open() {
		while (true) {
			System.out.println("<<<<< KH RentCar >>>>>");
			System.out.println("1. ȸ��");
			System.out.println("2. �մ�");
			System.out.println("0. ���α׷� ����");
			System.out.print("���� > ");
			int sel = sc.nextInt();
			switch (sel) {
			case 1:	//ȸ��
				company();
				break;
			case 2:	//�մ�
				client();
				break;
			
			case 0:	//����
				
				return;
			}
		}

	}
	
	public void company() {
		while (true) {
			System.out.println("1. �� ��ǰ ���");
			System.out.println("2. ���� ��Ȳ����");
			System.out.println("3. ���� ����");
			System.out.println("4. ���� ����");
			System.out.println("0. �޴� ������");
			System.out.print("���� > ");
			int sel = sc.nextInt();
			switch (sel) {
			case 1:
				insertProduct();
				break;
			case 2:
				showProduct();
				break;
			case 3:
				updateProduct();
				break;
			case 4:
				deleteProduct();
				break;
			case 0:
				return;
			}

		}
	}
	
	private void deleteProduct() {
		// TODO Auto-generated method stub
		if(search()) {
			
		}else {
			System.out.println("�� ã�ҽ��ϴ�");
		}
		
	}

	private void updateProduct() {
		// TODO Auto-generated method stub
		
	}

	private void showProduct() {
		// TODO Auto-generated method stub
		
	}

	public void insertProduct() {
		
	}
	
	public boolean search() {
		return true;
	}
	
	public void client() {
		
	}
	
}
