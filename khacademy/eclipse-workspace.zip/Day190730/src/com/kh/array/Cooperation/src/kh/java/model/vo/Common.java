package com.kh.array.Cooperation.src.kh.java.model.vo;

public class Common {
	// �⺻������
	private int price;
	private String identNum;
	private int day;
	private String name;
	private boolean insur;
	private int license;

	public Common() {

	}

	// �߰������� (�ֹι�ȣ, �̸�, ����, �ϼ�)
	public Common(String identNum, int price, int day) {
		this.identNum = identNum;
		this.price = price;
		this.day = day;
	}

	public Common(String identNum, int price, int day, 
			String name, boolean insur, int license) {
		this.identNum = identNum;
		this.price = price;
		this.day = day;
		this.name = name;
		this.insur = insur;
		this.license = license;
	}

	public boolean getInsur() {
		return insur;
	}

	public void setInsur(boolean insur) {
		this.insur = insur;
	}

	public int getLicense() {
		return license;
	}

	public void setLicense(int license) {
		this.license = license;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getIdentNum() {
		return identNum;
	}

	public void setIdentNum(String identNum) {
		this.identNum = identNum;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
