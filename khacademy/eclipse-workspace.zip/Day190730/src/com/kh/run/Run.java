package com.kh.run;

import com.kh.array.Array_Exam;
import com.kh.array.Array_a;
import com.kh.array.Array_b;
import com.kh.array.Array_copy;
import com.kh.array.Motel_System;
import com.kh.array2.Array2_a;
import com.kh.array2.Array_Practice;
import com.kh.array2.Kakao;
public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Array_a aa = new Array_a();
//		aa.test2();
//		Array_b ab = new Array_b();
//		ab.test2();
//		Motel_System ms = new Motel_System();
//		ms.motel_sys();
//		Array_copy ac = new Array_copy();
//		ac.test1();
//		Array_Exam ae = new Array_Exam();
//		ae.Lotto();
//		Array2_a a2a = new Array2_a();
//		a2a.test1();
//		Array_Practice ap = new Array_Practice();
//		ap.practice3();
		Kakao ka = new Kakao();
		ka.kakaoPro();
	}

}
