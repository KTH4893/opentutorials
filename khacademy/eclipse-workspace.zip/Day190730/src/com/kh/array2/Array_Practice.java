package com.kh.array2;

public class Array_Practice {
	public void practice1() {

		int[][] arr = new int[5][5];
		int k = 1;
		for (int i = 0; i < arr.length; i++) { // array[].length ���Ǳ���
			// arr[i][j] = i; array.length ���Ǳ���
			for (int j = arr[1].length - 1; j >= 0; j--) { // j = 4 3 2 1 0
				arr[i][j] = k;
				k++;
			}
		}
		// arr[][] ���
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[1].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();

		k = 1;
		int[][] arr1 = new int[5][5];
		for (int i = 0; i < arr1.length; i++) { // array[].length ���Ǳ���
			// arr1[i][j] = i; array.length ���Ǳ���
			for (int j = 0; j < arr1[1].length; j++) {
				arr1[j][i] = k;
				k++;
			}
		}
		// arr1[][]���
		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr1[1].length; j++) {
				System.out.print(arr1[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		k = 1;
		int[][] arr2 = new int[5][5];
		for (int i = 0; i < arr2.length; i++) { // array[].length ���Ǳ���
			// arr[i][j] = i; array.length ���Ǳ���
			for (int j = arr2[1].length - 1; j >= 0; j--) { // j = 4 3 2 1 0
				arr2[j][i] = k;
				k++;
			}
		}
		// arr2[][]���
		for (int i = 0; i < arr2.length; i++) {
			for (int j = 0; j < arr2[1].length; j++) {
				System.out.print(arr2[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		int[][] arr3 = new int[5][5];
		k = 1;

		for (int i = 0; i < arr3.length; i++) { // array[].length ���Ǳ���
			if (i % 2 == 0) { // array.length ���Ǳ���
				for (int j = 0; j < arr3[1].length; j++) {
					arr3[i][j] = k;
					k++;
				}
			} else if (i % 2 == 1) {
				for (int j = arr3[1].length - 1; j >= 0; j--) { // j = 4 3 2 1 0
					arr3[i][j] = k;
					k++;
				}
			}
		}
		// arr3[][]���
		for (int i = 0; i < arr3.length; i++) {
			for (int j = 0; j < arr3[1].length; j++) {
				System.out.print(arr3[i][j] + "\t");
			}
			System.out.println();
		}
	}

	public void practice2() {
		int[][] arr = new int[5][5];
		int k = 1;
		for (int i = 0; i < arr.length; i++) { // array[].length ���Ǳ���
			if (i % 2 == 0) { // array.length ���Ǳ���
				for (int j = arr[1].length - 1; j >= 0; j--) {
					arr[i][j] = k;
					k++;
				}
			} else if (i % 2 == 1) {
				for (int j = 0; j < arr[1].length; j++) { // j = 4 3 2 1 0
					arr[i][j] = k;
					k++;
				}
			}
		}
		// arr[][]���
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[1].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		int[][] arr1 = new int[5][5];
		k = 1;
		for (int i = 0; i < arr1.length; i++) { // array[].length ���Ǳ���
			if (i % 2 == 0) { // array.length ���Ǳ���
				for (int j = arr1[1].length - 1; j >= 0; j--) {
					arr1[j][i] = k;
					k++;
				}
			} else if (i % 2 == 1) {
				for (int j = 0; j < arr1[1].length; j++) { // j = 4 3 2 1 0
					arr1[j][i] = k;
					k++;
				}
			}
		}
		// arr1[][]���
		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr1[1].length; j++) {
				System.out.print(arr1[i][j] + "\t");
			}
			System.out.println();
		}
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		int[][] arr2 = new int[5][5];
		k = 1;
		for (int i = 0; i < arr2.length; i++) { // array[].length ���Ǳ���
			if (i % 2 == 0) { // array.length ���Ǳ���
				for (int j = 0; j < arr1[1].length; j++) {
					arr2[j][i] = k;
					k++;
				}
			} else if (i % 2 == 1) {
				for (int j = arr2[1].length - 1; j >= 0; j--) { // j = 4 3 2 1 0
					arr2[j][i] = k;
					k++;
				}
			}
		}
		// arr2[][]���
		for (int i = 0; i < arr2.length; i++) {
			for (int j = 0; j < arr2[1].length; j++) {
				System.out.print(arr2[i][j] + "\t");
			}
			System.out.println();
		}
	}

	public void practice3() {
		int[][] arr = new int[5][5];
		int k = 1;
		int a = arr.length; // ���� ���� 5
		int b = arr[1].length; // ���� ���� 5
		boolean bool = true; // ���ѷ��� ����
		while (bool) {
			switch (a) {
			case 5:
				for (int i = 0; i < a; i++) { // ù�� 1 2 3 4 5
					arr[0][i] = k++;
				}
				a--;
				b--; // ��� ���� ���̸� 1���� ���δ�. a b = 4
			case 4:
				for (int i = 0; i < a; i++) { // �ٿ�
					arr[1 + i][a] = k++;
				}
				for (int j = a; j > 0; j--) {
					arr[a][j - 1] = k++; // ����
				}

				a--;
				b--; // ��� ���� ���̸� 1���� ���δ�. a b = 3
			case 3:
				for (int i = a; i > 0; i--) { // ��
					arr[i][0] = k++;
				}
				for (int j = 0; j < a; j++) { // ������
					arr[1][j + 1] = k++;
				}

				a--;
				b--; // ��� ���� ���̸� 1���� ���δ�. a b = 2
			case 2:
				for (int i = 0; i < a; i++) { // �ٿ�
					arr[2 + i][3] = k++;
				}
				for (int j = a; j > 0; j--) {
					arr[3][j] = k++; // ����
				}

				a--;
				b--; // ��� ���� ���̸� 1���� ���δ�. a b = 1
			case 1:
				for (int i = a; i > 0; i--) { // ��
					arr[2][1] = k++;
				}

				for (int j = 0; j < a; j++) { // ������
					arr[2][2] = k++;
					break;
				}
				break;
			}
			
			break;
		}

		 for(int i = 0; i < arr.length; i++) {
		 for(int j = 0; j < arr[1].length; j++) {
		 System.out.print(arr[i][j]+ "\t");
		 }
		 System.out.println();
		 }

	}

}
