package com.kh.array2;

public class Array2_a {
	/* 2�����迭
	 * ---�ε��� 2�� ����Ͽ� ��� �����ִ� �迭
	 * ex) int [][] arr = new int [3][4];
	 * 		arr[0][1] = 3;
	 * [0 0] [0 1]=3 [0 2] [0 3]
	 * [1 0] [1 1] [1 2] [1 3]
	 * [2 0] [2 1] [2 2] [2 3]
	 * -> int [] arr = {1,2,3,4,5};
	 * -> int [][] arr = {{1,2,3,4,},{5,6,7,8},{9,0,1,2}};
	 * 1 2 3 4 
	 * 5 6 7 8
	 * 9 10 11 12
	 */
	
	
	public void test1() {
//		int [][] arr = {{1,2,3,4,},{5,6,7,8},{9,10,11,12}};
		int [][] arr1 = new int [3][4];
		int [][] arr2 = new int [3][4];
//		arr1[0][0] = 1;
//		arr1[0][1] = 2;
//		arr1[0][2] = 3;
//		arr1[0][3] = 4;
//		arr1[1][0] = 5;
//		arr1[1][1] = 6;
//		arr1[1][2] = 7;
//		arr1[1][3] = 8;
//		arr1[2][0] = 9;
//		arr1[2][1] = 10;
//		arr1[2][2] = 11;
//		arr1[2][3] = 12;
		//�࿭ ��������
		int k = 1;
		for(int i = 0; i < arr1.length; i++) {						//array[].length ���Ǳ���
		//	arr1[i][j] = i;														  array.length ���Ǳ���
			for(int j = 0; j < arr1[1].length; j++) {
					arr1[i][j] = k;
					k++;
			}
		}
		//�࿭ ��������
		int q = 12;
		for(int i = 0; i < arr2.length; i++) {						//array[].length ���Ǳ���
		//	arr1[i][j] = i;														  array.length ���Ǳ���
			for(int j = 0; j < arr2[1].length; j++) {
					arr2[i][j] = q;
					q--;
			}
		}
		//��¿�
		for(int i = 0; i < arr1.length; i++) {	
			for(int j = 0; j < arr1[1].length; j++) {
				System.out.print(arr1[i][j]+ "\t");
			}
			System.out.println();
		}
	
		
		
	}
}
