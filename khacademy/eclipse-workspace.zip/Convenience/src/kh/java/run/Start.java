package kh.java.run;

import kh.java.controller.ConMgr;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConMgr cm = new ConMgr();
		cm.open();
	}

}
