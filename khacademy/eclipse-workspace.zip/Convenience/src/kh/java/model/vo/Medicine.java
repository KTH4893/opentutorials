package kh.java.model.vo;

public class Medicine extends Common{
	private String expiredDate;
	
	
	public Medicine() {
		
	}
	public Medicine(int price, String quality, int amount, String name,
			String expiredDate) {
		super(price, quality, amount, name);
		this.expiredDate = expiredDate;
	}
	
	
	public String getExpiredDate() {
		return expiredDate;
	}
	public void setExpiredDate(String expiredDate) {
		this.expiredDate = expiredDate;
	}
	
	
	
}
