package kh.java.model.vo;

public class Common {
	//���� ǰ�� ���
	private int price;
	private String quality;
	private int amount;
	private String name;
	// �⺻ ������
	public Common(){
		
	}
	// �߰� ������
	public Common(int price, String quality, int amount, String name) {
		this.price = price;
		this.quality = quality;
		this.amount = amount;
		this.name = name;
	}
	public Common(int price, int amount, String name) {
		this.price = price;
		this.amount = amount;
		this.name = name;
	}
	
	
	
	//		getter/setter
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getQuality() {
		return quality;
	}
	public void setQuality(String quality) {
		this.quality = quality;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	
}
