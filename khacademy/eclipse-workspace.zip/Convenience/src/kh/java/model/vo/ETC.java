package kh.java.model.vo;

public class ETC extends Common{
	public ETC() {
		
	}
	
	public ETC(int price, String quality, int amount, String name) {
		super(price, quality, amount, name);
	}
	
}
