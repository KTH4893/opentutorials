package kh.java.model.vo;

public class InstantFood extends Common{
	private int calorie;
	private String expiredDate;
	
	public InstantFood() {
		// TODO Auto-generated constructor stub
	}
	public InstantFood(int price, String quality, int amount, String name,
			int calorie, String expiredDate) {
		super(price, quality, amount, name);
		this.calorie = calorie;
		this.expiredDate = expiredDate;
	}
	
	
	
	
	public int getCalorie() {
		return calorie;
	}
	public void setCalorie(int calorie) {
		this.calorie = calorie;
	}
	public String getExpiredDate() {
		return expiredDate;
	}
	public void setExpiredDate(String expiredDate) {
		this.expiredDate = expiredDate;
	}
	
	
	
	
}
