package kh.java.model.vo;

public class Drink extends Common{
	//�뷮, Į�θ�, �������
	private int volume;
	private int calorie;
	private String expiredDate;
	public Drink() {
		
	}
	public Drink(int price, String quality, int amount, String name,
			int volume, int calorie, String expiredDate) {
		super(price, quality, amount, name);	//����Ӽ��� ��ӹް�
		this.volume = volume;					//���μӼ��� ���� ����
		this.calorie = calorie;
		this.expiredDate = expiredDate;
		
	}
	
	
	
	
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
	public int getCalorie() {
		return calorie;
	}
	public void setCalorie(int calorie) {
		this.calorie = calorie;
	}
	public String getExpiredDate() {
		return expiredDate;
	}
	public void setExpiredDate(String expiredDate) {
		this.expiredDate = expiredDate;
	}
	
	
	
	
}
