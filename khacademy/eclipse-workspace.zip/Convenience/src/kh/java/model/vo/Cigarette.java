package kh.java.model.vo;

public class Cigarette extends Common{
	private int tar;
	private int nicotine;
	
	public Cigarette() {
		// TODO Auto-generated constructor stub
	}
	public Cigarette(int price, String quality, int amount, String name,
			int tar, int nicotine) {
		super(price, quality, amount, name);
		this.tar = tar;
		this.nicotine = nicotine;
	}
	
	
	
	public int getTar() {
		return tar;
	}
	public void setTar(int tar) {
		this.tar = tar;
	}
	public int getNicotine() {
		return nicotine;
	}
	public void setNicotine(int nicotine) {
		this.nicotine = nicotine;
	}
	
	
	
	
	
	
}
