package kh.java.model.vo;

public class Snack extends Common{
	private int calorie;
	private String expiredDate;
	private boolean boxing;
	
	public Snack() {
		
	}
	public Snack(int price, String quality, int amount, String name,
			int calorie, String expiredDate, boolean boxing) {
		super(price, quality, amount, name);
		this.calorie = calorie;
		this.expiredDate = expiredDate;
		this.boxing = boxing;
	}
	
	
	public int getCalorie() {
		return calorie;
	}
	public void setCalorie(int calorie) {
		this.calorie = calorie;
	}
	public String getExpiredDate() {
		return expiredDate;
	}
	public void setExpiredDate(String expiredDate) {
		this.expiredDate = expiredDate;
	}
	public boolean getBoxing() {
		return boxing;
	}
	public void setBoxing(boolean boxing) {
		this.boxing = boxing;
	}
	
	
	
}
