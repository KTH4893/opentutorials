package run;

import game.ShopName;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ShopName sn = new ShopName();
		sn.main();
	}

}
