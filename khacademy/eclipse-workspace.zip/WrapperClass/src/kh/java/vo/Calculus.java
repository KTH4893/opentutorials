package kh.java.vo;

import java.util.Scanner;

import kh.java.api.Calculator;

public class Calculus implements Calculator{
	Scanner sc = new Scanner(System.in);
	public void start() {
		System.out.println("������ �Է�(+,-,*,/) : ");
		char cal = sc.next().charAt(0);
		System.out.println("ù��° ���� �Է� : " );
		String su1 = sc.next();
		System.out.println("�ι�° ���� �Է� : " );
		String su2 = sc.next();
		switch (cal) {
		case '+':
			System.out.println("����� ������� : " + add(su1,su2));
			break;
		case '-':
			System.out.println("����� ������� : " + subtract(su1,su2));
			break;
		case '*':
			System.out.println("����� ������� : " + multiply(su1,su2));
			break;
		case '/':
			System.out.println("����� ������� : " + divide(su1,su2));
			break;
		}
	}
	public int add(String su1, String su2){
		
		return Integer.parseInt(su1)+ Integer.parseInt(su2);
	}
	public int subtract(String su1, String su2) {
		int i = Integer.parseInt(su1);
		int j = Integer.parseInt(su2);
		return i-j;
	}
	public int multiply(String su1, String su2) {
		int i = Integer.parseInt(su1);
		int j = Integer.parseInt(su2);
		return i*j;
	}
	public double divide(String su1, String su2) {
		double i = Double.parseDouble(su1);
		double j = Double.parseDouble(su2);
		return i/j;
	}
	@Override
	public int add(kh.java.api.String su1, kh.java.api.String su2) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int subtract(kh.java.api.String su1, kh.java.api.String su2) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int multiply(kh.java.api.String su1, kh.java.api.String su2) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public double divide(kh.java.api.String su1, kh.java.api.String su2) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
