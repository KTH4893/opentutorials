package kh.java.api;

public interface Calculator {
	public int add(String su1, String su2);
	public int subtract(String su1, String su2);
	public int multiply(String su1, String su2);
	public double divide(String su1, String su2);
	public void start();
	
}
