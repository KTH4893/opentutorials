package kh.java.run;

import java.sql.Time;

import kh.java.vo.Calculus;
import kh.java.vo.Practice;
import kh.java.vo.SBTest;
import kh.java.vo.Wrapper;

public class WrapperStart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Wrapper w = new Wrapper();
//		w.main();
//		Calculus ca = new Calculus();
//		ca.start();
//		SBTest sbt = new SBTest();
//		sbt.date();
		Practice pc = new Practice();
		pc.exam2();
	}

}
