package userStart;

public class Room {
	
	String [] room = {"��", "��", "��"};

	public Room() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Room(String[] room) {
		super();
		this.room = room;
	}

	public String[] getRoom() {
		return room;
	}

	public void setRoom(String[] room) {
		this.room = room;
	}
	
	
	
	
}
