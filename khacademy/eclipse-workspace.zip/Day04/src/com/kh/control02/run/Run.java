package com.kh.control02.run;

import com.kh.control02.loop.A_For;
import com.kh.control02.loop.LoopPractice;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A_For af = new A_For();
		LoopPractice ap = new LoopPractice();
		ap.practice10();
		
		//af.method12();
	}

}
