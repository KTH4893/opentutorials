package com.kh.control02.loop;

import java.util.Scanner;

public class LoopPractice {

	// ���� �Է� : 4
	// *
	// **
	// ***
	// ****

	public void practice1() {
		Scanner sc = new Scanner(System.in);
		System.out.println("�����Է� : ");
		int user = sc.nextInt();
		// for(int i = 1; i <= user; i ++) {
		// for(int j = 1; j <= user; j++) {
		// if(j <= i) {
		// System.out.printf("%s", '*');
		// }
		// }
		// System.out.println();
		// }
		for (int i = 0; i < user; i++) {
			for (int j = 0; j < user - i - 1; j++) {
				System.out.print(" "); // �������
			}
			for (int k = 0; k < i + 1; k++) {
				System.out.print("*"); // "*" ���
			}
			System.out.println();
		}

		for (int i = 0; i < user; i++) {
			for (int j = 1; j <= user; j++) {
				if (j >= user - i) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

	public void practice2() {
		// 1 + (1+2) + (1+2+3) + ....+ (1+2+3+4+5+6+7+8+9+10)�� ����� ����Ͻÿ�

		int sum = 0;
		int total = 0;
		for (int i = 1; i <= 10; i++) {
			sum += i; // sum = 1 , 1+2, 1+2+3, 1+2+3+4 .... 1+2+3+4+5+6+7+8+9+10
			total += sum;
			System.out.println(total);
		}

		// for(int i = 1; i <= 10; i++) {
		//
		//
		// }

	}

	public void practice3() {
		// �� ���� �ֻ����� ������ �� ���� ���� 6�� �Ǵ� ��� ����� ���� ����ϴ� ���α׷����ۼ��Ͻÿ�.
		// [����]
		// 1+5 = 6
		// 2+4 = 6
		// 3+3 = 6
		// 4+2 = 6
		// 5+1 = 6
		int sum = 6;
		// i + sum-i
		for (int i = 1; i < sum; i++) {
			System.out.printf("%d + %d = %d\n", i, (sum - i), sum);
		}
	}

	public void practice4() {
		/*
		 * Math.random()�� �̿��ؼ� 1���� 6������ ������ ������ ���� value�� �����ϴ� �ڵ带 �ϼ��϶�
		 */
		int num = (int) (Math.random() * 10 + 1);
		if (num <= 6 && num > 0) {
			int value = num;
			System.out.println(value);
		} else {
			System.out.println("0�̳� 6���ʰ�");
		}

		int val = (int) (Math.random() * 6 + 1);
		System.out.println("Value : " + val); // ���ʿ� 1~6�����ǰ��ۿ��ȳ��´�.
	}

	public void practice5() {
		// ���� �Է� : 3
		// *
		// **
		// ***
		// **
		// *
		Scanner sc = new Scanner(System.in);
		System.out.println("������ �Է��ϼ��� : ");
		int input = sc.nextInt();
		int input2 = input;
		// for(int i = 1; i <= input; i++) { //*
		// for(int j = 1; j <= i; j++) { //**
		// System.out.print("*"); //***�� ���
		// }
		// System.out.println();
		// }
		for (int i = 0; i < input; i++) {
			for (int j = 0; j < i + 1; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		int k = input;
		for (int i = 0; i < k; i++) { // i = 0 input = 4 i = 1 input =3
			for (int j = 0; j < input - 1; j++) { // j = 0 j < 3; j++ *** j = 0 j < 2j; j++ **
				System.out.print("*"); // i = 2 input = 2
			} // j = 0 j < 2; j ++ *
			System.out.println();
			--input;
		}
		/*
		 * for(int i = 0; i < input; i++) { for(int j = 0; j < i+1; j++) {
		 * System.out.print("*"); } System.out.println(); } for(int i = input-1 ; i>0 ;
		 * i--) { for(int j = 0; j < i; j++) { System.out.print("*"); }
		 * System.out.println(); }
		 */

		// for(int i = 1; i <= input; i++) { ���ѷ���
		// for(int j = 1; j >= i ; j++) {
		// System.out.printf("*");
		// }
		// System.out.println();
		// }

	}

	public void practice6() {

		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

	public void practice7() {

		for (int i = 1; i <= 5; i++) {
			for (int j = 0; j < 5; j++) {

				System.out.printf("%d", i);
			}
			System.out.println();
		}
	}

	public void practice8() {
		for (int i = 0; i <= 4; i++) {

			for (int j = 1; j <= 5; j++) {
				System.out.printf("%d", j);
			}
			System.out.println();
		}
	}

	public void practice9() {
		int k = 1;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.printf("%d", k++);
			}
			k -= 4;
			System.out.println();
		}
	}

	public void practice10() {

		for (int i = 5; i > 0; i--) {
			int k = i;
				for (int j = 0; j < 5; j++) {
					System.out.printf("%d", k++);
				}
				System.out.println();
		}
	}

}
