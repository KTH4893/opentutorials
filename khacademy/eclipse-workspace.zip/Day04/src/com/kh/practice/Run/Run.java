package com.kh.practice.Run;

import java.util.Scanner;

import com.kh.control01.condition.A_If;
import com.kh.control01.condition.B_Else;
import com.kh.control01.condition.C_Switch;
import com.kh.practice.OperatorPractice.OperatorPractice;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OperatorPractice op = new OperatorPractice();
		A_If condition = new A_If();
		B_Else be = new B_Else();
		C_Switch cs = new C_Switch();
		
		cs.method4();
		// be.method2();
		// condition.method2();

		// op.Practice10();

	}

}
