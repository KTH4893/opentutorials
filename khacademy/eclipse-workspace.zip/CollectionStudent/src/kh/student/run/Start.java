package kh.student.run;

import kh.student.view.StudentView;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StudentView sv = new StudentView();
		sv.main();
		
		
	}

}
