package kh.student.controller;

import java.util.ArrayList;
import java.util.Scanner;

import kh.student.vo.Student;

public class StudentController<T> {
	Scanner sc = new Scanner(System.in);
	ArrayList<Student> al = new ArrayList<Student>();
	
	public void selectAll(){
		for(int i = 0; i < al.size(); i++) {
			System.out.println(al.get(i).getClassNumber() + "\t" +al.get(i).getName()+ "\t" + al.get(i).getAge()+ "\t" + 
					al.get(i).getAddress()+ "\t" + al.get(i).getGrade());
		}
//		for(Student  stu : al) {
//			System.out.println(stu);
//		}
	}
	
	public ArrayList<Student> selectOne(int classNumber) {
		for(int i = 0; i < al.size(); i++) {
			if(al.get(i).getClassNumber() == classNumber) {
				System.out.println(al.get(i).getClassNumber() + "\t" +al.get(i).getName()+ "\t" + al.get(i).getAge()+ "\t" + 
						al.get(i).getAddress()+ "\t" + al.get(i).getGrade());
				break;
			}
		}
		return null;
	}
	
	public void insertStudent(Student s) {
		//arr[index] = s;
		//index++;
		al.add(s);
		System.out.println("�Է��� �Ϸ�Ǿ����ϴ�.");
	}
	
	
	
	public void updateStudent(Student oldStudent) {
		System.out.println("�й��� �Է����ּ���.");
		int classNumber = sc.nextInt();
		System.out.println("�̸��� �Է����ּ���.");
		String name = sc.next();
		System.out.println("���̸� �Է����ּ���.");
		int age = sc.nextInt();
		System.out.println("�ּҸ� �Է����ּ���.");
		sc.nextLine();
		String address = sc.nextLine();
		System.out.println("������ �Է����ּ���.");
		double grade = sc.nextDouble();
		Student newStudent = new Student(classNumber, name, age, address, grade);
		
	}
	
	
	
	public Student selectOneName(Student oldStudent) {
		for(int i = 0; i < al.size(); i ++) {
			if(al.get(i).getName().equals(oldStudent)) {
			}
		}
		return oldStudent;
	}
	
	
	
	public void deleteStudent(int classNumer) {
		System.out.println("������ �л��� �й��� �Է����ּ���.");
		int classNumber = sc.nextInt();
				for(int i = 0; i < al.size(); i++) {
			if(al.get(i).getClassNumber() == classNumber) {
				al.remove(i);
				break;
			}
		}
	}
	
	public int search(int classNumber) {
		for(int i = 0; i < al.size(); i++) {
			//arr[i]
			if(al.get(i).getClassNumber() == classNumber) {
				return i;
			}
		}
		return -1;
	}
	
	
	
}
