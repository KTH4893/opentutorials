package com.kh.run;

import com.kh.whileloop.Random_Test;
import com.kh.whileloop.While_A;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			While_A wa = new While_A();
			wa.whileTest6();
//			Random_Test rt = new Random_Test();
//			rt.randomTest1();
		
	}

}
