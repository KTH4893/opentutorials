package kh.java.run;

import kh.java.vo.LottoPjt;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LottoPjt lp = new LottoPjt();
		lp.main();
	}

}
