package kh.java.vo;

public class ExceptionTest2 extends Exception{

	public ExceptionTest2() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ExceptionTest2(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
