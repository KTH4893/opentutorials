package kh.java.vo;

public class ExceptionTest1 extends RuntimeException{

	public ExceptionTest1() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ExceptionTest1(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}		//Unchecked
	

}
