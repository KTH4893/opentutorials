package kh.java.run;

import java.util.HashMap;

import kh.java.test.HashMapTest;
import kh.java.test.ListTest;
import kh.java.test.SetTest;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		ListTest lt = new ListTest();
//		lt.exam();
//		SetTest st = new SetTest();
//		st.main();
		HashMapTest hmt = new HashMapTest();
		hmt.main();
		
	}

}
