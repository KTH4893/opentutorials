package kh.java.run;

import kh.java.practice.Quiz;
import kh.java.test.FileTest;

public class Start {
	public static void main(String[] args) {
		FileTest ft = new FileTest();
		ft.main();
	}
}
