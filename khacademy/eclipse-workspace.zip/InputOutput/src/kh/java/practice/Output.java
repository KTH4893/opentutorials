package kh.java.practice;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Output {
	Scanner sc = new Scanner(System.in);
	public void output() {
		FileWriter fw = null;
		
		String file = sc.next();
		try {
			fw = new FileWriter(file);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
