package kh.java.cmdtest;

import kh.java.test.SerializableTest;

public class Run {
	public static void main(String[] args) {
		SerializableTest s = new SerializableTest();
		s.main();
	}
}
