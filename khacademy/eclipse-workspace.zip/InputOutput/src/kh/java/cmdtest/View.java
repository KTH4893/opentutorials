package kh.java.cmdtest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class View {
	Scanner sc = new Scanner(System.in);
	UserInfo stu = new UserInfo();

	public void mainMenu() {
		while (true) {
			System.out.println("1. �����Է�");
			System.out.println("2. �������");
			System.out.println("3. ��������");
			System.out.println("4. ���� �ҷ�����");
			System.out.println("0. ����");
			System.out.print("���� > ");
			switch (sc.nextInt()) {
			case 1:
				insert();
				break;
			case 2:
				print();
				break;
			case 3:
				save();
				break;
			case 4:
				upload();
				break;
			case 0:
				return;
			}
		}
	}

	private void insert() {
		System.out.print("�̸� �Է� : ");
		stu.setName(sc.next());
		System.out.print("���� �Է� : ");
		stu.setAge(sc.nextInt());
		System.out.print("�ּ� �Է� : ");
		sc.nextLine();
		stu.setAddress(sc.nextLine());
	}

	private void print() {
		System.out.println("�̸� : " + stu.getName());
		System.out.println("���� : " + stu.getAge());
		System.out.println("�ּ� : " + stu.getAddress());
	}

	private void save() {
		if (stu.toString().equals(null)) {
			System.out.println("�Է��� ������ �����ϴ�.");
			return;
		}
		BufferedWriter bw = null;
		try {
			FileWriter fw = new FileWriter("C:\\Users\\user1\\Desktop\\info.txt");
			bw = new BufferedWriter(fw);
			bw.write(stu.getName() + "/" + stu.getAge() + "/" + stu.getAddress());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("������ �Ϸ�Ǿ����ϴ�.");
	}

	private void upload() {
		BufferedReader br = null;
		try {
			FileReader fr = new FileReader("C:\\Users\\user1\\Desktop\\info.txt");
			br = new BufferedReader(fr);
			String temp = br.readLine();
			StringTokenizer st = new StringTokenizer(temp, "/");
						
			stu.setName(st.nextToken());
			stu.setAge(Integer.parseInt(st.nextToken()));
			stu.setAddress(st.nextToken());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
