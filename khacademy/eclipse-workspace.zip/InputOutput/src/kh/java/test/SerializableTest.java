package kh.java.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

import kh.java.cmdtest.UserInfo;

public class SerializableTest {
	Scanner sc = new Scanner(System.in);
	UserInfo user = new UserInfo("������", "121",20,"����");
	ArrayList<UserInfo> users = new ArrayList<UserInfo>();
	public SerializableTest() {
		users.add(new UserInfo("������1", "1234", 200, "����"));
	}

	public void main() {
		while (true) {
			System.out.println("1.���� ���� ��������");
			System.out.println("2.���� �о����");
			System.out.println("���� > ");
			switch (sc.nextInt()) {
			case 1:
				objectOutput();
				break;
			case 2:
				readObject();
				break;
			default:
				return;
			}
		}
	}

	public void objectOutput() {
		ObjectOutputStream oos = null;
		FileOutputStream fos;
		try {
			fos = new FileOutputStream("object.txt");
			oos = new ObjectOutputStream(fos);
			oos.writeObject(users);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("����Ϸ�");
	}

	public void readObject() {
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("object.txt"))){
//			UserInfo ui = (UserInfo)ois.readObject();
			ArrayList<UserInfo> al = (ArrayList<UserInfo>)ois.readObject();//ArrayList�� ������ �� �ø���������� �Ǿ� �ִ�.
			for(UserInfo ui : al) {
				System.out.println(ui.getName());
			}
//			System.out.println(ui.getName());
//			System.out.println(ui.getPassword());
//			System.out.println(ui.getAge());
//			System.out.println(ui.getAddress());
			
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
