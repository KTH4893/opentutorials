package kh.java.test.input;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


public class CharStream {
	Scanner sc = new Scanner(System.in);

	public void readFile() {
		System.out.print("�ε��� ���ϸ� �Է� : ");
		String fileName = sc.next();
		BufferedReader br = null;
		try {
			FileReader fr = new FileReader("C:\\Users\\user1\\Desktop\\" + fileName);
			br = new BufferedReader(fr);
			int lineNumber = 1;
			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}
				System.out.println((lineNumber++) + " : " + line);
			}
		} catch (FileNotFoundException e) {
			System.out.println("������ �� ã�ҽ��ϴ�.");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}
