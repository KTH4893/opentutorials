package kh.java.test;

public class ExamRun {
	public static void main(String[] args) {
		Exam e = new Exam();
		e.main();
	}
}
