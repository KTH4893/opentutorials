package com.kh.edu;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class TestJavaApi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date = new Date();
		System.out.println(date);
		/*						System.out.println(new Date());						*/
		/*						System.out.println(Localdate.now(ZoneId.of("Europe/Paris")));				Timezone Ŭ�������;��� */
		/*						System.out.println(ZonedDateTime.now().format((DateTimeFormatter.RFC_1123_DATE_TIME));		*/
	}
			// ���� int a = 100, a = a+10( = 110) a = 110                  ///////  ���     final a = 100, a = a+10( = 110)<---�� ��ü�� ����, a = 100				??
}
