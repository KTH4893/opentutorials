package kh.java.point.run;

import kh.java.point.controller.PntMgr;

public class TestMain {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PntMgr pm = new PntMgr();
		pm.start();
	}

}
