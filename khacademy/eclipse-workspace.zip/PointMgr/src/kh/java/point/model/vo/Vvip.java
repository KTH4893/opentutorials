package kh.java.point.model.vo;

public class Vvip extends Grade{
	public Vvip() {
		
	}
	
	
	public Vvip(String grade, String name, int point) {
		super(grade, name, point);
	}
	
	
	public double getBonus() {
		return getPoint() * 0.3;
	}
	
	
}
