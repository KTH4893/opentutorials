package org.kh.controller;

import java.util.ArrayList;

import org.kh.model.dao.MemberDao;
import org.kh.model.vo.Member;
import org.kh.view.MemberView;

public class MemberController {
	MemberDao md = new MemberDao();
	MemberView mv = new MemberView();	//출력 메소드를 사용하기위함 printMsg
	public void printAll() {
		ArrayList<Member> list = md.printAll();
		for(Member m : list) {
			mv.printMsg(m.toString());
		}
	}

	public Member searchId(String searchId) {
		Member m = md.searchId(searchId);
		if(m!=null) {
			mv.printMsg(m.toString());
		} else {
			mv.printMsg("회원정보가 없습니다.");
		}
		return m;
	}
	
	public void searchName(String searchName){
		ArrayList<Member> list = md.searchName(searchName);
		if(list.isEmpty()) {
			mv.printMsg("회원정보가 없습니다.");
		}else {
			for(Member m : list) {
				mv.printMsg(m.toString());
			}
		}
	}
	
	public void insertMember(Member m) {
		int result = md.insertMember(m);
		if(result>0) {
			mv.printMsg("회원가입 성공!");
		} else {
			mv.printMsg("회원가입 실패!");
		}
	}
	
	public int updateMember(Member m) {
		int result = md.updateMember(m);
		return result;
	}
	
	public void updateMember2(String searchId) {
		Member m = md.searchId(searchId);
		if(m==null) {		//정보가 없으면
			mv.printMsg("회원정보가 없습니다.");
			return;
		}
		Member updateMember = mv.updateMember2();
		updateMember.setMemberId(searchId);
		int result = md.updateMember(updateMember);
		if(result>0) {
			mv.printMsg("정보변경 성공.");
		}else {
			mv.printMsg("정보변경 실패.");
		}
	}
	
	
	
	public int deleteMember(String memberId) {
		int result = md.deleteMember(memberId);
		
		return result;
	}
	
	public void deleteMember2(String memberId) {
		int result = md.deleteMember(memberId);
		if(result>0) {
			mv.printMsg("삭제성공.");
		}else {
			mv.printMsg("회원정보가 없습니다.");
		}
		
		
		
	}
	
	
}
