package org.kh.model.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.kh.model.vo.Member;

public class MemberDao {

	public ArrayList<Member> printAll() {
		// 조회 결과를 담을 list객체를 생성
		ArrayList<Member> list = new ArrayList<Member>();
		// DBMS연결 객체
		Connection conn = null;
		// SQL구문 사용 객체
		Statement stmt = null;
		// Select 결과 저장 객체
		ResultSet rset = null;
		// 전송할 쿼리문
		String query = "Select * from member";

		// 1. 사용할 DB에 대한 드라이버등록(클래스등록)
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2. 등록된 클래스를 이용해서 DB연결
			// -> 실패하면 NULL -> 성공시 Connection객체생성
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "jdbc", "1234");
			// java와 database를 연결하는 jdbc를할건데 oracle을쓸거다 접속방식은 thin으로 쓸거고 접속주소는
			// localhost1521번에서
			// 접속정보는 무료버젼은 xe 유료버젼은 체크값을 sid를 매번 다르게줌
			// jdbc 웹 아이디에 비밀번호 1234를 넣음

			
			// 3. 쿼리문을 실행할 Statement 객체를 생성
			stmt = conn.createStatement();
			// 4. 쿼리문 전송하고 실행결과 받기
			rset = stmt.executeQuery(query);
			while(rset.next()) {	//다음커서위치에 데이터가 있으면 멤버 객체를만들어서 거기에 저장
				String memberId = rset.getString("member_id");
				//resultSet에서 String값을 가져올게 Column값이 member_id인
				String memberPw = rset.getString("member_pw");
				String memberName = rset.getString("member_name");
				String email = rset.getString("email");
				int age = rset.getInt("age");
				String addr = rset.getString("addr");
				String gender = rset.getString("gender");
				Date enrollDate = rset.getDate("enroll_date");
				Member m = new Member(memberId, memberPw, memberName, age, gender, email, addr, enrollDate);
				list.add(m);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} // 패키지명 oracle.jdbc.driver //클래스명 OracleDriver
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rset.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
	}

	public Member searchId(String searchId) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rset = null;
		Member m = null;
		String query = "select * from member where member_id = '" + searchId + "'";		//select * from member where member_id = 'searchId'
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","jdbc","1234");
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			if(rset.next()) {
				m = new Member();
				m.setMemberId(rset.getString("member_id"));
				m.setMemberPw(rset.getString("member_pw"));
				m.setMemberName(rset.getString("member_name"));
				m.setEmail(rset.getString("email"));
				m.setAge(rset.getInt("age"));
				m.setAddr(rset.getString("addr"));
				m.setEnrolDate(rset.getDate("enroll_date"));
				m.setGender(rset.getString("gender"));
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rset.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return m;
	}
	
	public ArrayList<Member> searchName(String searchName){
		// 조회 결과를 담을 list객체를 생성
		ArrayList<Member> list = new ArrayList<Member>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rset = null;	
		String query = "SELECT * FROM MEMBER where member_name LIKE ('%"+ searchName +"%')";
		// "select * from member where member_id = '" + searchId + "'";	
		//SELECT * FROM MEMBER where member_name LIKE ('%    이름    %');
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","jdbc","1234");
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			while(rset.next()) {
				String memberId = rset.getString("member_id");
				String memberPw = rset.getString("member_pw");
				String memberName = rset.getString("member_name");
				String email = rset.getString("email");
				int age = rset.getInt("age");
				String addr = rset.getString("addr");
				String gender = rset.getString("gender");
				Date enrollDate = rset.getDate("enroll_date");
				Member m = new Member(memberId, memberPw, memberName, age, gender, email, addr, enrollDate);
				list.add(m);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rset.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public int insertMember(Member m) {	//insert가 수행되면 x행이 적용되었다는 결과값이나와 리턴타입을 int로둔다. 
		// ResultSet rset = null;		insert를하는거지 select해서 resultSet값을 저장하는게 필요없다
		int result = 0;
		Statement stmt = null;
		Connection conn = null;
		String query = "insert into member values("
	            + "'" + m.getMemberId() + "',"
	            + "'" + m.getMemberPw() + "',"
	            + "'" + m.getMemberName() + "',"
	            + "'" + m.getEmail() + "',"
	            + m.getAge() + ","
	            + "'" + m.getAddr() + "',"
	            + "'" + m.getGender() + "',"
	            +"sysdate)";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "jdbc", "1234");
			stmt = conn.createStatement();
			result = stmt.executeUpdate(query);
			if(result > 0) {			// 정상적으로 insert가되면 commit해주고 아니면 rollback
				conn.commit();
			} else {
				conn.rollback();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public int deleteMember(String memberId) {
		int result = 0;
		Statement stmt = null;
		Connection conn = null;
		String query = "DELETE FROM MEMBER WHERE MEMBER_ID LIKE ('"+ memberId +"')";
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","jdbc","1234");
			stmt = conn.createStatement();
			result = stmt.executeUpdate(query);
			if(result>0) {
				conn.commit();
			}else {
				conn.rollback();
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return result;
		
	}
	
	public int updateMember(Member m) {
		int result = 0;
		Connection conn = null;
		Statement stmt = null;
		//UPDATE MEMBER SET 
//		MEMBER_NAME = m.getMemberName(), EMAIL = m.getEmail(), ADDR = m.getAddr(), GENDER = m.getGender() WHERE MEMBER_ID = m.getMemberId();
//		MEMBER_NAME = '이름9', EMAIL = 'EMAIL9', ADDR = '주소9', GENDER = '여' WHERE MEMBER_ID = 'ID7'; 
		String query = "UPDATE MEMBER SET MEMBER_NAME = '"+ m.getMemberName() + "',"
				+"EMAIL = '" + m.getEmail() + "',"
				+"ADDR = '" +m.getAddr() + "',"
				+"GENDER = '" +m.getGender() +"'" +
				"WHERE MEMBER_ID = '" +m.getMemberId() + "'";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","jdbc","1234");
			//ip주소받아서 localhost 대신쓰고
			//상대방 방화벽내리면
			//db검색 가능
			stmt = conn.createStatement();
			result = stmt.executeUpdate(query);
			if(result>0) {
				conn.commit();
			} else {
				conn.rollback();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
}
