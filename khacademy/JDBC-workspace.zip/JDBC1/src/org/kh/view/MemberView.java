package org.kh.view;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Scanner;

import org.kh.controller.MemberController;
import org.kh.model.vo.Member;

public class MemberView {
	Scanner sc = new Scanner(System.in);

	public void mainMenu() {
		MemberController mc = new MemberController();
		while (true) {
			System.out.println("===회원관리 프로그램===");
			System.out.println("1. 회원정보 전체조회"); // SELECT
			System.out.println("2. 회원 아이디 조회"); // SELECT
			System.out.println("3. 회원 이름으로 검색"); // SELECT
			System.out.println("4. 회원 가입"); // INSERT
			System.out.println("5. 회원 정보 변경"); // UPDATE
			System.out.println("6. 회원 탈퇴"); // DELETE
			System.out.println("0. 프로그램 종료");
			System.out.print("선택 > ");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				mc.printAll();
				break;
			case 2:
				mc.searchId(inputId("조회"));
				break;
			case 3:
				mc.searchName(searchName());
				break;
			case 4:
				mc.insertMember(insertMember());
				break;
			case 5:
				//아이디를 입력받아서 존재하는 경우에 변경정보 받아서 수정
				//update -> 이름, 이메일, 주소, 성별
				mc.updateMember2(inputId("수정"));
				break;
			case 6:
				mc.deleteMember(inputId("삭제"));
				break;
			case 0:
				System.out.println("정말로 종료하시겠습니까?(y/n): ");
				String end = sc.next();
				if (end.toUpperCase().charAt(0) == 'Y') { // <- 대문자여도 종료가능하게 하는 구문
					return;
				}
			}
		}
	}

//	public void printAll() {
//		ArrayList<Member> list = mc.printAll();
//		for (Member m : list) {
//			System.out.println(m);
//		}
//	}

//	public void searchId() {
//		System.out.print("조회할 ID를 입력하세요 : ");
//		String searchId = sc.next();
//		Member m = mc.searchId(searchId); // 한명이니까 그냥 Member로 받으면된다.
//		if (m != null) {
//			System.out.println(m);
//		} else {
//			System.out.println("회원정보가 없습니다.");
//		}
//
//	}

	public String searchName() {
		// 이름 입력받아서 해당 이름이 있는지 조회
		// 이름이 포함되면 전부 다 조회되어야함
		System.out.print("조회할 이름을 입력하세요");
		String searchName = sc.next();
//		ArrayList<Member> list = 
//		mc.searchName(searchName);
		return searchName;
	}
	
	public Member insertMember() {
		System.out.print("아이디 입력 : ");
		String memberId = sc.next();
		System.out.print("비밀번호 입력 : ");
		String memberPw = sc.next();
		System.out.print("이름 입력 : ");
		String memberName = sc.next();
		System.out.print("이메일 입력 : ");
		String email = sc.next();
		System.out.print("나이 입력 : ");
		int age = sc.nextInt();
		System.out.print("주소 입력 : ");
		String addr = sc.next();
		System.out.print("성별 입력 : ");
		String gender = sc.next();
		Member m = new Member(memberId, memberPw, memberName, age, gender, email, addr, null);
		return m;
	}
	
	public void updateMember() {
		System.out.print("수정할 아이디 입력 : ");
		String memberId = sc.next();
		
		System.out.print("변경될 이름 입력 : ");
		String memberNewName = sc.next();
		System.out.print("변경될 이메일 입력 : ");
		String Newemail = sc.next();
		System.out.print("변경될 주소 입력 : ");
		String Newaddr = sc.next();
		System.out.print("변경될 성별 입력 : ");
		String Newgender = sc.next();
		
		
		
		//Member m = mc.searchId(memberId);
		Member m = new Member(memberId, null, memberNewName, 0, Newgender, Newemail, Newaddr, null);
		
		int result = updateMember(m);
		if(result > 0) {
			System.out.println("정보가 변경되었습니다.");
		} else {
			System.out.println("수정할 ID를 찾지못했습니다.");
		}
	}
	
	
	public Member updateMember2() {
		Member m = new Member();
		System.out.print("이름 입력 : ");
		String memberName = sc.next();
		System.out.print("이메일 입력 : ");
		String email = sc.next();
		System.out.print("주소 입력 : ");
		String addr = sc.next();
		System.out.print("성별 입력 : ");
		String gender = sc.next();
		m.setMemberName(memberName);
		m.setEmail(email);
		m.setAddr(addr);
		m.setGender(gender);
		return m;
	}
	
	
	public void deleteMember() {
		System.out.print("탈퇴할ID 입력 : ");
		String memberId = sc.next();
		int result = mc.deleteMember(memberId);
		if(result > 0) {
			System.out.println("탈퇴가 완료되었습니다.");
		} else {
			System.out.println("탈퇴할ID가 없습니다.");
		}
	}
	
	public String inputId(String str) {
		System.out.print(str + "할 회원 아이디를 입력하세요.");
		String memberId = sc.next();
		return memberId;
		//삭제 성공실패는 Controller가 할일
		
	}
	public void printMsg(String msg) {
		System.out.println(msg);
	}
	
	
}
